var vm = new Vue({
	el:'#rateBody',
	data(){
		return{
			
		}
	},
	methods:{
		all(){
			axios.get('https://www.showdoc.cc/zxf?page_id=2169269711717464').then(res=>{
				console.log(res)
			}).catch(err=>{
				console.log(err)
			})
		}
	},
	mounted(){
		this.all()
	}
})