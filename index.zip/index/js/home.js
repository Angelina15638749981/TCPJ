var vm = new Vue({
	el:'#home',
	data(){
		return{
			
		}
	},
	mounted(){
		
	},
	methods:{
		
	},
	components:{
		
	}
})