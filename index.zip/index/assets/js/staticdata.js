﻿(function () {
    CDK = {
        token: "",
        host: "http://192.168.2.111",

        get:function (url, dataType, async, data,succ,error) {
            $.ajax({
                type: "get",
                url: CDK.host + url,
                dataType: dataType,
                async: async,
                data:data,
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("token", CDK.token);
                },
                success: function (result) {
                    if (succ) {
                        succ(result);
                    }
                }, error: function (errorMsg) {
                    if (error) {
                        error(errorMsg);
                    }
                }
            });
        },

        post:function (url, dataType, async, data,succ,error) {
            $.ajax({
                type: "post",
                url: CDK.host + url,
                dataType: dataType,
                async: async,
                data:data,
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("token", CDK.token);
                },
                success: function (result) {
                    if (succ) {
                        succ(result);
                    }
                }, error: function (errorMsg) {
                    if (error) {
                        error(errorMsg);
                    }
                }
            });
        }
    }

})(jQuery);