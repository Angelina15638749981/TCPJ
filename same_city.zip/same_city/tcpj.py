﻿import requests
import time
import json
from lxml import etree
import re
from pymongo import MongoClient
import random
import datetime
# import schedule

# def write_to_mongodb(data):
#     for item in data:
#         if mongo_collection.update_one(item, {'$set': item}, upsert=True):
#             # if mongo_collection.insert_one(item):
#             print('存储成功')
#         else:
#             print('存储失败')


ip_pool = [
    '112.85.165.158',
    '113.121.22.89',
    '112.85.128.47',
'118.24.148.74',
'221.225.165.194',
'163.204.241.107',
'182.90.246.24',
'60.13.42.34',
'180.160.76.53',
'182.108.44.47',
'111.226.211.105',
'112.85.128.59',
'182.90.246.24',
'27.11.201.245',
'1.197.203.53',
'1.58.10.19',
'118.190.145.138',
'112.85.149.178',
'163.204.242.160',
'112.85.131.172',
'122.226.135.89',
'139.129.207.72',
'112.85.130.51',
'60.13.42.176',
'182.108.44.47',
'1.58.10.19',
'112.85.171.21',
'112.85.129.36',
'120.83.107.235',
'163.204.247.101',
'123.232.199.89',
'180.160.76.53',
'171.12.113.201',
'112.85.131.179',
'112.85.131.41',
'118.190.145.138',
'112.85.128.91',
'112.85.131.172',
'112.85.129.110'

]


def ip_proxy():
    ip = ip_pool[random.randrange(0, len(ip_pool))]
    proxy_ip = 'http://' + ip
    proxies = {'http': proxy_ip}
    return proxies



def get_data_from_tcpj():
    # present_time = time.strftime('%H:%M', time.localtime(time.time()))
    # print("---------------------------当前时间------------------------------")
    # print("当前时间:%s" % present_time)

    # 随即设置
    user_agents = [
        "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Win64; x64; Trident/5.0; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 2.0.50727; Media Center PC 6.0)",
        "Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)",
        "Mozilla/4.0 (compatible; MSIE 7.0b; Windows NT 5.2; .NET CLR 1.1.4322; .NET CLR 2.0.50727; InfoPath.2; .NET CLR 3.0.04506.30)",
        "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN) AppleWebKit/523.15 (KHTML, like Gecko, Safari/419.3) Arora/0.3 (Change: 287 c9dfb30)",
        "Mozilla/5.0 (X11; U; Linux; en-US) AppleWebKit/527+ (KHTML, like Gecko, Safari/419.3) Arora/0.6",
        "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.2pre) Gecko/20070215 K-Ninja/2.1.1",
        "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9) Gecko/20080705 Firefox/3.0 Kapiko/3.0",
        "Mozilla/5.0 (X11; Linux i686; U;) Gecko/20070322 Kazehakase/0.4.5",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36"
    ]
    user_agent = random.choice(user_agents)
    headers = {
        "User-Agent": user_agent}
    try:
        response = requests.get("https://www.tcpjw.com/OrderList/TradingCenter", headers=headers,proxies=ip_proxy())
        # response = requests.get("https://www.tcpjw.com/OrderList/TradingCenter", headers=headers)
        response.encoding = "utf-8"
        Html = response.text
        html = etree.HTML(Html)
        #  1时间 3金额 4expire_date 6annual_interest 11operation
        # content_below_td = html.xpath('//*[@id="tb"]/tr[1]/td[10]/a')[0].text
        # print(content_below_td)
        # item_time = html.xpath('//*[@id="tb"]/tr[1]/td')[1].text
        # print(item_time)
        # 2person 5interest_every_100_thousand 7defect_spot
        # content_below_td_span = html.xpath('//*[@id="tb"]/tr[15]/td/span')
        # for x in content_below_td:
        #     print(x.text)
        # for y in content_below_td_span:
        #     print(y.text)

        for i in range(15, 0, -1):
            with open('tcpjw_data_test_0523.txt', 'a+') as f:
                    # 1 时间
                    item_time = html.xpath('//*[@id="tb"]/tr[%s]/td' % i)[0].text.strip("\n")
                    item_time_ = "2019-" + item_time.replace('.', '-')+":00"
                    # time_ = datetime.datetime.strptime(item_time_, '%Y-%m-%d %H:%M')-datetime.timedelta(hours=8)
                    time_ = int(time.mktime(time.strptime(item_time_, '%Y-%m-%d %H:%M:%S')))
                    # print(time_)
                    # print(type(time_))
                    # 2 person
                    item_person = html.xpath('//*[@id="tb"]/tr[%s]/td/span' % i)[0].text.strip("\n")
                    # 3 amount
                    item_amount = html.xpath('//*[@id="tb"]/tr[%s]/td'% i)[2].text.strip("\n")
                    # amount = int(item_amount)
                    # print(amount)
                    # print(type(amount))
                    # 4 expire_date
                    expire_date = html.xpath('//*[@id="tb"]/tr[%s]/td'% i)[3].text.replace('\n', '').replace('\t', '') .replace(' ', '')
                    if expire_date[-5] == "剩":
                        days_to_expire_date = int(expire_date[-4:-1])
                    elif expire_date[-4] == "剩":
                        days_to_expire_date = int(expire_date[-3:-1])
                    elif expire_date[-3] == "剩":
                        days_to_expire_date = int(expire_date[-2:-1])

                    # print(days_to_expire_date)
                    # 5 interest_every_100_thousand
                    interest_every_100_thousand = html.xpath('//*[@id="tb"]/tr[%s]/td/span' % i)[1].text.strip("\n")
                    # 6 annual_interest
                    annual_interest = html.xpath('//*[@id="tb"]/tr[%s]/td' % i)[5].text.strip("\n")
                    # 7 defect_spot% i)% i)
                    defect_spot = html.xpath('//*[@id="tb"]/tr[%s]/td/span' % i)[2].text.strip("\n")
                    # operation
                    order_state =html.xpath('//*[@id="tb"]/tr[%s]/td[10]/a' % i)[0].text.strip("\n")

                    # 城商 有问题
                    bank_belongto_chengshang_list = ["农业", "中国银行", "建设", "浦发", "广发", "中信", "招商", "广大", "民生",
                                                     "华夏", "平安", "兴业", "交通",
                                                     "浙商", "渤海", "宁波", "江苏", "北京", "上海", "南京",
                                                     "农村", "农商",
                                                     "村镇",
                                                     "财务"]
                    for bank in bank_belongto_chengshang_list:
                        if bank not in item_person:
                            band_type = "城商"
                            judgement_basis = "城商"




                    # 国股
                    bank_belongto_guogu_list = ["农业", "中国银行", "建设", "浦发", "广发", "中信", "招商", "广大", "民生", "华夏", "平安",
                                                "兴业", "交通"]
                    for bank in bank_belongto_guogu_list:
                        if bank in item_person:
                            band_type = "国股"
                            judgement_basis = bank



                    # 大商
                    bank_belongto_dashang_list = ["浙商", "渤海", "宁波", "江苏", "北京", "上海", "南京"]
                    for bank in bank_belongto_dashang_list:
                        if bank in item_person:
                            band_type = "大商"
                            judgement_basis = bank


                    # 三农
                    bank_belongto_sannong_list = ["农村", "农商"]
                    for bank in bank_belongto_sannong_list:
                        if bank in item_person:
                            band_type = "三农"
                            judgement_basis = bank



                    # 村镇
                    bank_belongto_cunzheng_list = ["村镇"]
                    for bank in bank_belongto_cunzheng_list:
                        if bank in item_person:
                            band_type = "村镇"
                            judgement_basis = bank

                    # 财务
                    bank_belongto_caiwu_list = ["财务"]
                    for bank in bank_belongto_caiwu_list:
                        if bank in item_person:
                            band_type = "财务"
                            judgement_basis = bank

                    # 向集合同城票据中插入一条文档
                    data = [{"band_type": band_type,
                            "judgement_basis": judgement_basis,
                            'publish_time': time_,
                            'person': item_person,
                            'amount': float(item_amount),
                            'expire_date': days_to_expire_date,
                             'interest_every_100_thousand': int(interest_every_100_thousand),
                            'annual_interest': annual_interest,
                                       'defect_spot': defect_spot,
                                       "operation": order_state}]

                    for item in data:
                        if col.update_one(item, {'$set': item}, upsert=True):
                            print('存储成功')


                    # 写入文件
                    f.write( band_type + ',' + judgement_basis + ',' + item_time + ',' + item_person + ',' + item_amount + ',' + expire_date + ',' +
                                interest_every_100_thousand + ',' + annual_interest + ',' + defect_spot + "\n")

                    print("---------爬取第%s行数据--------------------------------------------------------" % i)
                    # print("bank_type：blabla")
                    # print("judgement_basis：blabla")
                    print("publish_time: %s" % item_time)
                    # print("person: %s" % item_person)
                    # print("amount: %s" % int(item_amount))
                    # print("expire_date: %s" % int(days_to_expire_date))
                    # print("interest_every_100_thousand: %s" % int(interest_every_100_thousand))
                    # print(" annual_interest: %s" % annual_interest)
                     # print("defect_spot: %s" % defect_spot)
                    # break
    except IndexError as e:
        print(e)


if  __name__ == '__main__':
    # 创建连接对象
    client = MongoClient(host='localhost', port=27017)
    # 获得数据库，此处使用 同城票据 数据库
    db = client.bank
    col = db.data
    while True:
        get_data_from_tcpj()



# schedule.every().day.at("17:49").do(get_data_from_tcpj)
# while True:
#     schedule.run_pending()
#     time.sleep(1)








