from django.db import models

# Create your models here.
import mongoengine
class Data(mongoengine.Document):
    # 银行类型
    band_type = mongoengine.StringField(max_length=50, null=True)
    # 判断依据
    judgement_basis = mongoengine.StringField(max_length=50, null=True)
    # 发布时间
    publish_time = mongoengine.IntField(null=True)
    # 承税人
    person = mongoengine.IntField(null=True)
    # 金额（万元）
    amount = mongoengine.FloatField(null=True)
    # 到期日
    expire_date = mongoengine.IntField(null=True)
    # 每十万扣息
    interest_every_100_thousand = mongoengine.IntField(null=True)
    # 年息
    annual_interest = mongoengine.StringField(max_length=50, null=True)
    # 瑕疵
    defect_spot = mongoengine.StringField(max_length=50, null=True)
    #订单状态
    operation = mongoengine.StringField(max_length=50, null=True)







