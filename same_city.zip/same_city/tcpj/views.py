import datetime
import json
import time
from functools import reduce

from mongoengine.queryset.visitor import Q
from django.http import JsonResponse
from django.shortcuts import render, redirect

# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render,HttpResponse
from django.urls import reverse

from .models import Data


# def shuju(gs, ss, cs, ds, cg ,cz,
#                         money1="", money2="", day1="", day2="", time1="", time2="",
#                         money3="", money4="", day3="", day4="", time3="", time4="",
#                         money5="", money6="", day5="", day6="", time5="", time6="",
#                         money7="", money8="", day7="", day8="", time7="", time8="",
#                         money9="", money10="", day9="", day10="", time9="", time10="",
#                         money11="",money12="",day11="",day12="",time11="",time12="",):
# 返回数据函数
def shuju(gs, ss, cs, ds, cg, cz,):

    list = [gs, ss, cs, ds, cg, cz]
    # 最高价格和更新时间
    money_best = []
    # 最近10条的最高价格和更新时间
    time_money_best = []
    # 平均价格
    avg_money = []
    # 10条价格
    ten_count = []
    for i in list:
        try:
            best = i.order_by("-interest_every_100_thousand")[0]
        except:
            best = 0
        money_best.append(best)
        try:
            time_best = i.order_by("-publish_time", "-interest_every_100_thousand")[0:10]
        except:
            time_best = 0
        try:
            count = [round(i["interest_every_100_thousand"],2) for i in time_best]
        except:
            count = 0
        ten_count.append(count)
        time_money_best.append(time_best)
        try:
            avg = round(reduce(lambda x, y: x + y, count)/len(count), 2)
        except:
            avg = 0
        avg_money.append(avg)

    # 国股数据使用try找到则返回 无则返回无数据
    try:
        gss = [{"money": round(money_best[0]["interest_every_100_thousand"], 2),
          "push_time": time.strftime("%m-%d %H:%M",time.localtime(money_best[0]["publish_time"])),
          "ten_money": round(time_money_best[0][0]["interest_every_100_thousand"], 2),
          "ten_money_push_time": time.strftime("%m-%d %H:%M", time.localtime(time_money_best[0][0]["publish_time"])),
          "avg": avg_money[0], "ten": ten_count[0]}]
    except:
        gss = [{"money": "无数据",
          "push_time": "无数据",
          "ten_money": "无数据",
          "ten_money_push_time": "无数据",
          "avg": "无数据", "ten":[],}]

    # 城商数据
    try:
        css = [{"money": money_best[2]["interest_every_100_thousand"], "push_time": time.strftime("%m-%d %H:%M",time.localtime(money_best[2]["publish_time"])),
                 "ten_money": time_money_best[2][0]["interest_every_100_thousand"], "ten_money_push_time": time.strftime("%m-%d %H:%M", time.localtime(time_money_best[2][0]["publish_time"])),
                 "avg": avg_money[2], "ten": ten_count[2]}]
    except:
        css = [{"money": "无数据",
          "push_time": "无数据",
          "ten_money": "无数据",
          "ten_money_push_time": "无数据",
          "avg": "无数据", "ten":[]}]

    # 三农
    try:
        sss = [{"money": money_best[1]["interest_every_100_thousand"], "push_time": time.strftime("%m-%d %H:%M",time.localtime(money_best[1]["publish_time"])),
                 "ten_money": time_money_best[1][0]["interest_every_100_thousand"], "ten_money_push_time": time.strftime("%m-%d %H:%M",time.localtime(time_money_best[1][0]["publish_time"])),
                 "avg": avg_money[1],"ten": ten_count[3]}]
    except:
        sss = [{"money": "无数据",
          "push_time": "无数据",
          "ten_money": "无数据",
          "ten_money_push_time": "无数据",
          "avg": "无数据", "ten":[]}]

    # 大商
    try:
        dss = [{"money": money_best[3]["interest_every_100_thousand"], "push_time": time.strftime("%m-%d %H:%M",time.localtime(money_best[3]["publish_time"])),
                 "ten_money": time_money_best[3][0]["interest_every_100_thousand"], "ten_money_push_time":time.strftime("%m-%d %H:%M", time.localtime(time_money_best[3][0]["publish_time"])),
                 "avg": avg_money[3], "ten": ten_count[3]}]
    except:
        dss = [{"money": "无数据",
          "push_time": "无数据",
          "ten_money": "无数据",
          "ten_money_push_time": "无数据",
          "avg": "无数据", "ten":[]}]

    # 财务
    try:
        cgs = [{"money": money_best[4]["interest_every_100_thousand"], "push_time":time.strftime("%m-%d %H:%M", time.localtime(money_best[4]["publish_time"])),
                 "ten_money": time_money_best[4][0]["interest_every_100_thousand"], "ten_money_push_time": time.strftime("%m-%d %H:%M",time.localtime(time_money_best[4][0]["publish_time"])),
                 "avg": avg_money[4], "ten": ten_count[4]}]
    except:
        cgs = [{"money": "无数据",
          "push_time": "无数据",
          "ten_money": "无数据",
          "ten_money_push_time": "无数据",
          "avg": "无数据", "ten":[]}]

    # 城镇
    try:
        czs = [{"money": money_best[5]["interest_every_100_thousand"],"push_time": time.strftime("%m-%d %H:%M", time.localtime(money_best[5]["publish_time"])),
                 "ten_money": time_money_best[5][0]["interest_every_100_thousand"],"ten_money_push_time": time.strftime("%m-%d %H:%M",time.localtime(time_money_best[5][0]["publish_time"])),
                 "avg": avg_money[5], "ten": ten_count[5]}]
    except:
        czs = [{"money": "无数据",
          "push_time": "无数据",
          "ten_money": "无数据",
          "ten_money_push_time": "无数据",
          "avg": "无数据", "ten":[]}]

    data = {
        "gss": gss,
        "sss": sss,
        "css": css,
        "dss": dss,
        "cgs": cgs,
        "czs": czs,
    }
    return data


def info1(request):
    # 查询字典
    condtions1 = {}
    condtions2 = {}
    condtions3 = {}
    condtions4 = {}
    condtions5 = {}
    condtions6 = {}
    # other代表是否有瑕疵
    other = request.GET.get("other")
    day1 = request.GET.get("day1")
    day2 = request.GET.get("day2")
    time1 = request.GET.get("time1")
    time2 = request.GET.get("time2")
    money1 = request.GET.get("money1")
    money2 = request.GET.get("money2")

    # 国股
    if time1 == "" or not time1:
        time1 = 0
    if time2 == "" or not time2:
        time2 = 0
    now = datetime.datetime.now()
    start = now-datetime.timedelta(hours=int(time1),minutes=int(time2))
    time_int = time.mktime(start.timetuple())
    condtions1["band_type"]="国股"
    if day1 and day1 != "":
        condtions1["expire_date__gte"] = int(day1)
    if day2 and day2 != "":
        condtions1["expire_date__lte"] = int(day2)
    if time1!=0 or time2!=0:
        condtions1["publish_time__gte"] = time_int
    if money1 and money1!="":
        condtions1["amount__gte"] = int(money1)
    if money2 and money2!="":
        condtions1["amount__lte"] = int(money2)

    # 三农
    day3 = request.GET.get("day3")
    day4 = request.GET.get("day4")
    time3 = request.GET.get("time3")
    time4 = request.GET.get("time4")
    money3 = request.GET.get("money3")
    money4 = request.GET.get("money4")
    if time3 == "" or not time3:
        time3 = 0
    if time4 == "" or not time4:
        time4 = 0
    now = datetime.datetime.now()
    start = now-datetime.timedelta(hours=int(time3),minutes=int(time4))
    time_int = time.mktime(start.timetuple())
    condtions2["band_type"]="三农"
    if day3 and day3!="":
        condtions2["expire_date__gte"] = int(day3)
    if day4 and day4!="":
        condtions2["expire_date__lte"] = int(day4)
    if time3!=0 or time4!=0:
        condtions2["publish_time__lte"] = time_int
    if money3 and money3!="":
        condtions2["amount__gte"] = int(money3)
    if money4 and money4!="":
        condtions2["amount__lte"] = int(money4)

    # 城商
    day5 = request.GET.get("day5")
    day6 = request.GET.get("day6")
    time5 = request.GET.get("time5")
    time6 = request.GET.get("time6")
    money5 = request.GET.get("money5")
    money6 = request.GET.get("money6")
    if time5 == "" or not time5:
        time5 = 0
    if time6 == "" or not time6:
        time6 = 0
    now = datetime.datetime.now()
    start = now-datetime.timedelta(hours=int(time5),minutes=int(time6))
    time_int = time.mktime(start.timetuple())
    condtions3["band_type"]="城商"
    if day5 and day5!="":
        condtions3["expire_date__gte"] = int(day5)
    if day6 and day6!="":
        condtions3["expire_date__lte"] = int(day6)
    if time5!=0 or time6!=0:
        condtions3["publish_time__lte"] = time_int
    if money5 and money5!="":
        condtions3["amount__gte"] = int(money5)
    if money6 and money6!="":
        condtions3["amount__lte"] = int(money6)

    # 大商
    day7 = request.GET.get("day7")
    day8 = request.GET.get("day8")
    time7 = request.GET.get("time7")
    time8 = request.GET.get("time8")
    money7 = request.GET.get("money7")
    money8 = request.GET.get("money8")
    if time7 == "" or not time7:
        time7 = 0
    if time8 == "" or not time8:
        time8 = 0
    now = datetime.datetime.now()
    start = now-datetime.timedelta(hours=int(time7),minutes=int(time8))
    time_int = time.mktime(start.timetuple())
    condtions4["band_type"]="大商"
    if day7 and day7!="":
        condtions4["expire_date__gte"] = int(day7)
    if day8 and day8!="":
        condtions4["expire_date__lte"] = int(day8)
    if time7!=0 or time8!=0:
        condtions4["publish_time__lte"] = time_int
    if money7 and money7!="":
        condtions4["amount__gte"] = int(money7)
    if money8 and money8!="":
        condtions4["amount__lte"] = int(money8)

    # 财务
    day9 = request.GET.get("day9")
    day10 = request.GET.get("day10")
    time9 = request.GET.get("time9")
    time10 = request.GET.get("time10")
    money9 = request.GET.get("money9")
    money10 = request.GET.get("money10")
    if time9 == "" or not time9:
        time9 = 0
    if time10 == "" or not time10:
        time10 = 0
    now = datetime.datetime.now()
    start = now-datetime.timedelta(hours=int(time9),minutes=int(time10))
    time_int = time.mktime(start.timetuple())
    condtions5["band_type"]="财务"
    if day9 and day9!="":
        condtions5["expire_date__gte"] = int(day9)
    if day10 and day10!="":
        condtions5["expire_date__lte"] = int(day10)
    if time9!=0 or time10!=0:
        condtions5["publish_time__lte"] = time_int
    if money9 and money9!="":
        condtions5["amount__gte"] = int(money9)
    if money10 and money10!="":
        condtions5["amount__lte"] = int(money10)


    # 村镇
    day11 = request.GET.get("day11")
    day12 = request.GET.get("day12")
    time11 = request.GET.get("time11")
    time12 = request.GET.get("time12")
    money11 = request.GET.get("money11")
    money12 = request.GET.get("money12")
    if time11 == "" or not time11:
        time11 = 0
    if time12 == "" or not time12:
        time12 = 0
    now = datetime.datetime.now()
    start = now - datetime.timedelta(hours=int(time11), minutes=int(time12))
    time_int = time.mktime(start.timetuple())
    condtions6["band_type"] = "村镇"
    if day11 and day11 != "":
        condtions6["expire_date__gte"] = int(day11)
    if day12 and day12 != "":
        condtions6["expire_date__lte"] = int(day12)
    if time11 != 0 or time12 != 0:
        condtions6["publish_time__lte"] = time_int
    if money11 and money11 != "":
        condtions6["amount__gte"] = int(money11)
    if money12 and money12 != "":
        condtions6["amount__lte"] = int(money12)

    if other:
        gs = Data.objects.filter(defect_spot='有').filter(band_type="国股")
        ss = Data.objects.filter(defect_spot='有').filter(band_type="三农")
        cs = Data.objects.filter(defect_spot='有').filter(band_type="城商")
        ds = Data.objects.filter(defect_spot='有').filter(band_type="大商")
        cg = Data.objects.filter(defect_spot='有').filter(band_type="财务")
        cz = Data.objects.filter(defect_spot='有').filter(band_type="村镇")
    else:
        gs = Data.objects.filter(defect_spot='无').filter(**condtions1)
        ss = Data.objects.filter(defect_spot='无').filter(**condtions2)
        cs = Data.objects.filter(defect_spot='无').filter(**condtions3)
        ds = Data.objects.filter(defect_spot='无').filter(**condtions4)
        cg = Data.objects.filter(defect_spot='无').filter(**condtions5)
        cz = Data.objects.filter(defect_spot='无').filter(**condtions6)
    data = shuju(gs, ss, cs, ds, cg, cz,)
    # with open("test.txt", "w") as f:
    #     f.write(str(data))
    # return redirect(reverse("index"))
    # return JsonResponse(data)
    return render(request,"data_info.html",context=data)

def wechat(request):
    with open(r"C:\Users\admin\Desktop\TCPJW\图灵机器人\test.txt", "r") as f:
        list = eval(f.read())
        data = {
            "roobots": list
        }
    return render(request, "data.html", context=data)


nowTime = datetime.datetime.now().strftime('%Y_%m_%d')  # 现在

def pya(request):
    with open(r"C:\Users\admin\Desktop\TCPJW\certify_code\pya1_html_%s.txt"%nowTime, "r") as f:
        list = eval(f.read())
        pya_data = {
            "pya_bank_info": list
        }
    return render(request, "pya.html", context=pya_data)